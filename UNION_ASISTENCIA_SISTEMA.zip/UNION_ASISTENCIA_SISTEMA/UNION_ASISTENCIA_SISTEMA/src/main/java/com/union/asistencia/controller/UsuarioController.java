package com.union.asistencia.controller;

import com.union.asistencia.dao.UsuarioDAO;
import com.union.asistencia.model.Usuario;
import com.union.asistencia.util.PasswordUtils;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import lombok.extern.java.Log;
import java.time.LocalDateTime;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Log
public class UsuarioController implements BaseController {

    @FXML private TableView<Usuario> tableView;
    @FXML private TableColumn<Usuario, Integer> colId;
    @FXML private TableColumn<Usuario, String> colUsername;
    @FXML private TableColumn<Usuario, String> colNombre;
    @FXML private TableColumn<Usuario, String> colApellido;
    @FXML private TableColumn<Usuario, String> colEmail;
    @FXML private TableColumn<Usuario, String> colRol;
    @FXML private TableColumn<Usuario, String> colFechaCreacion;
    @FXML private TableColumn<Usuario, Boolean> colActivo;

    @FXML private TextField txtUsername;
    @FXML private PasswordField txtPassword;
    @FXML private TextField txtNombre;
    @FXML private TextField txtApellido;
    @FXML private TextField txtEmail;
    @FXML private ComboBox<String> cbxRol;
    @FXML private CheckBox chkActivo;
    @FXML private TextField txtBuscar;

    @FXML private Button btnGuardar;
    @FXML private Button btnCancelar;
    @FXML private Button btnGenerarPassword;

    private ObservableList<Usuario> usuariosList;
    private UsuarioDAO usuarioDAO;
    private Usuario usuarioLogueado;
    private Usuario usuarioSeleccionado;

    @Override
    public void setUsuarioLogueado(Usuario usuario) {
        this.usuarioLogueado = usuario;
        inicializar();
    }

    @FXML
    private void initialize() {
        usuarioDAO = new UsuarioDAO();
        usuariosList = FXCollections.observableArrayList();
        usuarioSeleccionado = null;

        configurarTabla();
        configurarCombobox();
        configurarEventos();

        tableView.setItems(usuariosList);
    }

    private void inicializar() {
        cargarDatos();
        limpiarFormulario();
    }

    private void configurarTabla() {
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colUsername.setCellValueFactory(new PropertyValueFactory<>("username"));
        colNombre.setCellValueFactory(new PropertyValueFactory<>("nombre"));
        colApellido.setCellValueFactory(new PropertyValueFactory<>("apellido"));
        colEmail.setCellValueFactory(new PropertyValueFactory<>("email"));
        colRol.setCellValueFactory(new PropertyValueFactory<>("rol"));
        colActivo.setCellValueFactory(new PropertyValueFactory<>("activo"));

        // ✅ SOLUCIÓN: Usar StringValueFactory para la fecha
        colFechaCreacion.setCellValueFactory(cellData -> {
            Usuario usuario = cellData.getValue();
            if (usuario.getFechaCreacion() != null) {
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
                return new SimpleStringProperty(usuario.getFechaCreacion().format(formatter));
            } else {
                return new SimpleStringProperty("");
            }
        });

        // Formatear activo
        colActivo.setCellFactory(tc -> new TableCell<Usuario, Boolean>() {
            @Override
            protected void updateItem(Boolean item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                    setStyle("");
                } else {
                    setText(item ? "✅ Activo" : "❌ Inactivo");
                    if (item) {
                        setStyle("-fx-text-fill: #27ae60; -fx-font-weight: bold;");
                    } else {
                        setStyle("-fx-text-fill: #e74c3c; -fx-font-weight: bold;");
                    }
                }
            }
        });
    }

    private void configurarCombobox() {
        cbxRol.getItems().addAll("ADMIN", "DOCENTE", "COORDINADOR");
    }

    private void configurarEventos() {
        tableView.getSelectionModel().selectedItemProperty().addListener(
                (obs, oldSelection, newSelection) -> {
                    if (newSelection != null) {
                        usuarioSeleccionado = newSelection;
                        cargarDatosFormulario(newSelection);
                    }
                });

        tableView.setOnMouseClicked(event -> {
            if (event.getClickCount() == 1 && tableView.getSelectionModel().getSelectedItem() == null) {
                limpiarSeleccion();
            }
        });
    }

    private void cargarDatos() {
        usuariosList.setAll(usuarioDAO.obtenerTodos());
    }

    @FXML
    private void guardarUsuario() {
        if (validarFormulario()) {
            Usuario usuario;
            boolean esNuevo = false;

            if (usuarioSeleccionado == null) {
                usuario = new Usuario();
                esNuevo = true;
            } else {
                usuario = usuarioSeleccionado;
            }

            usuario.setUsername(txtUsername.getText().trim());

            // Solo actualizar password si se proporcionó uno nuevo
            if (!txtPassword.getText().isEmpty()) {
                usuario.setPasswordHash(PasswordUtils.hashPassword(txtPassword.getText()));
            } else if (esNuevo) {
                // Para usuario nuevo, password es obligatorio
                mostrarAlerta("Error", "La contraseña es obligatoria para nuevos usuarios", Alert.AlertType.ERROR);
                return;
            }

            usuario.setNombre(txtNombre.getText().trim());
            usuario.setApellido(txtApellido.getText().trim());
            usuario.setEmail(txtEmail.getText().trim());
            usuario.setRol(cbxRol.getValue());
            usuario.setActivo(chkActivo.isSelected());

            boolean exito;
            if (esNuevo) {
                exito = usuarioDAO.crearUsuario(usuario);
            } else {
                exito = usuarioDAO.actualizar(usuario);
            }

            if (exito) {
                mostrarAlerta("Éxito",
                        esNuevo ? "Usuario registrado correctamente" : "Usuario actualizado correctamente",
                        Alert.AlertType.INFORMATION);
                limpiarFormulario();
                cargarDatos();
            } else {
                mostrarAlerta("Error",
                        esNuevo ? "No se pudo registrar el usuario" : "No se pudo actualizar el usuario",
                        Alert.AlertType.ERROR);
            }
        }
    }

    @FXML
    private void generarPassword() {
        String nuevaPassword = PasswordUtils.generateRandomPassword();
        txtPassword.setText(nuevaPassword);
        mostrarAlerta("Contraseña Generada",
                "Se ha generado una nueva contraseña: " + nuevaPassword +
                        "\n\nGuárdela en un lugar seguro.", Alert.AlertType.INFORMATION);
    }

    @FXML
    private void cancelar() {
        limpiarFormulario();
    }

    // ✅ MÉTODO CORREGIDO
    @FXML
    private void buscarUsuarios() {
        String criterio = txtBuscar.getText().trim();
        if (criterio.isEmpty()) {
            cargarDatos();
        } else {
            // CORRECCIÓN: Usar una nueva lista filtrada en lugar de modificar la existente
            ObservableList<Usuario> usuariosFiltrados = FXCollections.observableArrayList();

            for (Usuario usuario : usuariosList) {
                if (usuario.getUsername().toLowerCase().contains(criterio.toLowerCase()) ||
                        usuario.getNombre().toLowerCase().contains(criterio.toLowerCase()) ||
                        usuario.getApellido().toLowerCase().contains(criterio.toLowerCase()) ||
                        usuario.getEmail().toLowerCase().contains(criterio.toLowerCase())) {
                    usuariosFiltrados.add(usuario);
                }
            }

            tableView.setItems(usuariosFiltrados);
        }
    }

    private boolean validarFormulario() {
        StringBuilder errores = new StringBuilder();

        if (txtUsername.getText().trim().isEmpty()) {
            errores.append("• El nombre de usuario es obligatorio\n");
        }

        if (usuarioSeleccionado == null && txtPassword.getText().isEmpty()) {
            errores.append("• La contraseña es obligatoria para nuevos usuarios\n");
        }

        if (txtNombre.getText().trim().isEmpty()) {
            errores.append("• El nombre es obligatorio\n");
        }

        if (txtApellido.getText().trim().isEmpty()) {
            errores.append("• El apellido es obligatorio\n");
        }

        if (txtEmail.getText().trim().isEmpty()) {
            errores.append("• El email es obligatorio\n");
        } else if (!txtEmail.getText().trim().matches("^[A-Za-z0-9+_.-]+@(.+)$")) {
            errores.append("• El formato del email no es válido\n");
        }

        if (cbxRol.getValue() == null) {
            errores.append("• El rol es obligatorio\n");
        }

        if (errores.length() > 0) {
            mostrarAlerta("Error de Validación", "Por favor corrija los siguientes errores:\n\n" + errores.toString(), Alert.AlertType.ERROR);
            return false;
        }

        return true;
    }

    private void cargarDatosFormulario(Usuario usuario) {
        txtUsername.setText(usuario.getUsername());
        txtPassword.clear(); // No mostrar password actual
        txtNombre.setText(usuario.getNombre());
        txtApellido.setText(usuario.getApellido());
        txtEmail.setText(usuario.getEmail());
        cbxRol.setValue(usuario.getRol());
        chkActivo.setSelected(usuario.getActivo());

        btnGuardar.setText("💾 Actualizar Usuario");
    }

    private void limpiarFormulario() {
        txtUsername.clear();
        txtPassword.clear();
        txtNombre.clear();
        txtApellido.clear();
        txtEmail.clear();
        cbxRol.getSelectionModel().clearSelection();
        chkActivo.setSelected(true);
        txtBuscar.clear();

        limpiarSeleccion();
    }

    private void limpiarSeleccion() {
        tableView.getSelectionModel().clearSelection();
        usuarioSeleccionado = null;
        btnGuardar.setText("💾 Guardar Usuario");
    }

    private void mostrarAlerta(String titulo, String mensaje, Alert.AlertType tipo) {
        Alert alert = new Alert(tipo);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }
}

