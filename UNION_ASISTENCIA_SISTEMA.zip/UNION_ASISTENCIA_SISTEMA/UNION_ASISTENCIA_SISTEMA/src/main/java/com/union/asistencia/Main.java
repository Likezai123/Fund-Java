package com.union.asistencia;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/com/union/asistencia/view/login.fxml"));
            Scene scene = new Scene(root, 1000, 700);

            // Aplicar CSS
            scene.getStylesheets().add(getClass().getResource("/com/union/asistencia/css/styles.css").toExternalForm());

            primaryStage.setTitle("Universidad Peruana Unión - Sistema de Gestión de Asistencia");
            primaryStage.setScene(scene);
            primaryStage.setResizable(false);
            primaryStage.show();

        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Error al iniciar la aplicación: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}