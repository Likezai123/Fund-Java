package com.union.asistencia.model;

import lombok.*;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Usuario {
    private Integer id;
    private String username;
    private String passwordHash;
    private String nombre;
    private String apellido;
    private String email;
    private String rol;
    private LocalDateTime fechaCreacion;
    private Boolean activo;

    // Método personalizado adicional
    public String getNombreCompleto() {
        return nombre + " " + apellido;
    }
}