package com.union.asistencia.controller;

import com.union.asistencia.model.Usuario;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import lombok.extern.java.Log;

import java.io.IOException;
import java.util.prefs.Preferences;

@Log
public class MainController {

    @FXML private Label lblUsuario;
    @FXML private Label lblRol;
    @FXML private VBox contentPane;
    @FXML private ComboBox<String> cbxTemas;
    @FXML private MenuButton btnConfiguracion;

    private Usuario usuarioLogueado;
    private Preferences prefs;

    public void setUsuarioLogueado(Usuario usuario) {
        try {
            this.usuarioLogueado = usuario;
            System.out.println("🔧 Configurando usuario: " + usuario.getUsername());

            // Configurar UI de forma SEGURA - no crashea si elementos son null
            if (lblUsuario != null) {
                lblUsuario.setText("Usuario: " + usuario.getNombre() + " " + usuario.getApellido());
                System.out.println("✅ lblUsuario configurado");
            }

            if (lblRol != null) {
                lblRol.setText("Rol: " + usuario.getRol());
                System.out.println("✅ lblRol configurado");
            }

            System.out.println("✅ Ventana principal configurada exitosamente");

        } catch (Exception e) {
            System.out.println("❌ Error en setUsuarioLogueado: " + e.getMessage());
            // No mostrar error al usuario, solo log
        }
    }

    @FXML
    private void initialize() {
        // Inicialización adicional si es necesaria
    }

    private void configurarSelectorTemas() {
        cbxTemas.getItems().addAll("Tema Claro", "Tema Oscuro", "Tema Institucional");
        cbxTemas.setValue("Tema Institucional");

        cbxTemas.setOnAction(e -> cambiarTema());
    }

    private void cargarTemaPreferido() {
        String temaGuardado = prefs.get("tema_preferido", "Tema Institucional");
        cbxTemas.setValue(temaGuardado);
        aplicarTema(temaGuardado);
    }

    private void cambiarTema() {
        String temaSeleccionado = cbxTemas.getValue();
        prefs.put("tema_preferido", temaSeleccionado);
        aplicarTema(temaSeleccionado);
    }

    private void aplicarTema(String tema) {
        Scene scene = lblUsuario.getScene();
        if (scene != null) {
            scene.getStylesheets().clear();
            scene.getRoot().getStyleClass().removeAll("light-theme", "dark-theme", "institutional-theme");

            switch (tema) {
                case "Tema Claro":
                    scene.getRoot().getStyleClass().add("light-theme");
                    break;
                case "Tema Oscuro":
                    scene.getRoot().getStyleClass().add("dark-theme");
                    break;
                case "Tema Institucional":
                    scene.getRoot().getStyleClass().add("institutional-theme");
                    break;
            }

            scene.getStylesheets().add(getClass().getResource("/com/union/asistencia/css/styles.css").toExternalForm());
        }
    }

    // Métodos para cargar cada módulo
    @FXML private void cargarEstudiantes() { cargarVentana("estudiante"); }
    @FXML private void cargarDocentes() { cargarVentana("docente"); }
    @FXML private void cargarAsignaturas() { cargarVentana("asignatura"); }
    @FXML private void cargarAsistencias() { cargarVentana("asistencia"); }
    @FXML private void cargarHorarios() { cargarVentana("horario"); }
    @FXML private void cargarAulas() { cargarVentana("aula"); }
    @FXML private void cargarReportes() { cargarVentana("reporte"); }
    @FXML private void cargarUsuarios() { cargarVentana("usuario"); }
    @FXML private void cargarEventos() { cargarVentana("evento"); }
    @FXML private void cargarConfiguracion() { cargarVentana("configuracion"); }

    @FXML
    private void cerrarSesion() {
        try {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Cerrar Sesión");
            alert.setHeaderText("¿Está seguro que desea cerrar sesión?");
            alert.setContentText("Será redirigido a la pantalla de login.");

            if (alert.showAndWait().get() == ButtonType.OK) {
                Stage stage = (Stage) lblUsuario.getScene().getWindow();
                Parent root = FXMLLoader.load(getClass().getResource("/com/union/asistencia/view/login.fxml"));
                Scene scene = new Scene(root, 1000, 700);

                scene.getStylesheets().add(getClass().getResource("/com/union/asistencia/css/styles.css").toExternalForm());

                stage.setScene(scene);
                stage.setTitle("Universidad Peruana Unión - Login");
                stage.setMaximized(false);
                stage.centerOnScreen();
            }
        } catch (IOException e) {
            log.severe("Error al cerrar sesión: " + e.getMessage());
            mostrarError("Error al cerrar sesión: " + e.getMessage());
        }
    }

    @FXML
    private void abrirConfiguracion() {
        mostrarInfo("Configuración del sistema - Próximamente");
    }

    @FXML
    private void abrirAcercaDe() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Acerca de");
        alert.setHeaderText("Universidad Peruana Unión - Sistema de Gestión de Asistencia");
        alert.setContentText("Versión: 1.0.0\n\n" +
                "Desarrollado para:\n" +
                "Universidad Peruana Unión\n\n" +
                "Características:\n" +
                "• Gestión completa de estudiantes y docentes\n" +
                "• Control de asistencia con múltiples métodos\n" +
                "• Gestión de horarios y aulas\n" +
                "• Reportes y estadísticas avanzadas\n" +
                "• Gestión de eventos académicos\n" +
                "• Sistema de seguridad avanzado\n\n" +
                "© 2024 - Universidad Peruana Unión");
        alert.showAndWait();
    }

    private void cargarVentana(String fxmlName) {
        try {
            System.out.println("🔄 Cargando ventana: " + fxmlName);

            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/union/asistencia/view/" + fxmlName + ".fxml"));
            Parent root = loader.load();

            // Pasar usuario logueado a los controladores si es necesario
            Object controller = loader.getController();
            if (controller instanceof BaseController) {
                ((BaseController) controller).setUsuarioLogueado(usuarioLogueado);
            }

            // Para VBox en lugar de AnchorPane
            contentPane.getChildren().setAll(root);

            System.out.println("✅ Ventana " + fxmlName + " cargada exitosamente");

        } catch (IOException e) {
            System.out.println("❌ Error al cargar la ventana: " + fxmlName + " - " + e.getMessage());
            mostrarError("Error al cargar la ventana: " + fxmlName);
        }
    }

    private void mostrarError(String mensaje) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }

    private void mostrarInfo(String mensaje) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Información");
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }

    // Agrega este método en MainController.java si no lo tienes
    @FXML
    private void cargarDashboard() {
        // Este método se llamará cuando quieras cargar un dashboard específico
        System.out.println("📊 Intentando cargar dashboard...");
        mostrarInfo("Dashboard - Próximamente");
    }

}

// Interfaz base para controladores
interface BaseController {
    void setUsuarioLogueado(Usuario usuario);
}