package com.union.asistencia.controller;

import com.union.asistencia.model.Usuario;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.FileChooser;

import java.io.File;
import java.util.prefs.Preferences;

public class ConfiguracionController implements BaseController {

    @FXML private ComboBox<String> cbxTema;
    @FXML private TextField txtNombreUniversidad;
    @FXML private TextField txtDireccion;
    @FXML private TextField txtTelefono;
    @FXML private TextField txtEmail;
    @FXML private TextField txtRector;
    @FXML private Button btnSeleccionarLogo;
    @FXML private Label lblRutaLogo;
    @FXML private CheckBox chkNotificaciones;
    @FXML private CheckBox chkBackupAutomatico;
    @FXML private Spinner<Integer> spnIntervaloBackup;
    @FXML private Button btnGuardarConfig;

    private Usuario usuarioLogueado;
    private Preferences prefs;

    @Override
    public void setUsuarioLogueado(Usuario usuario) {
        this.usuarioLogueado = usuario;
        inicializar();
    }

    @FXML
    private void initialize() {
        prefs = Preferences.userNodeForPackage(ConfiguracionController.class);
        configurarCombobox();
        configurarSpinner();
        cargarConfiguracion();
    }

    private void inicializar() {
        // Cargar configuración actual
    }

    private void configurarCombobox() {
        cbxTema.getItems().addAll("Tema Claro", "Tema Oscuro", "Tema Institucional");

        // Agregar listener para cambiar tema
        cbxTema.getSelectionModel().selectedItemProperty().addListener(
                (obs, oldVal, newVal) -> {
                    if (newVal != null) {
                        aplicarTema(newVal);
                    }
                });
    }

    private void configurarSpinner() {
        SpinnerValueFactory<Integer> valueFactory =
                new SpinnerValueFactory.IntegerSpinnerValueFactory(1, 24, 6);
        spnIntervaloBackup.setValueFactory(valueFactory);
    }

    private void cargarConfiguracion() {
        // Cargar preferencias
        cbxTema.setValue(prefs.get("tema_preferido", "Tema Institucional"));
        txtNombreUniversidad.setText(prefs.get("nombre_universidad", "Universidad Peruana Unión"));
        txtDireccion.setText(prefs.get("direccion", "Carretera Central Km. 19.5, Ñaña, Lurigancho-Chosica"));
        txtTelefono.setText(prefs.get("telefono", "(01) 123-4567"));
        txtEmail.setText(prefs.get("email", "info@upeu.edu.pe"));
        txtRector.setText(prefs.get("rector", "Dr. John Wesley"));
        lblRutaLogo.setText(prefs.get("ruta_logo", "logo_upeu.png"));
        chkNotificaciones.setSelected(prefs.getBoolean("notificaciones", true));
        chkBackupAutomatico.setSelected(prefs.getBoolean("backup_automatico", true));
        spnIntervaloBackup.getValueFactory().setValue(prefs.getInt("intervalo_backup", 6));
    }

    @FXML
    private void seleccionarLogo() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Seleccionar Logo");
        fileChooser.getExtensionFilters().add(
                new FileChooser.ExtensionFilter("Imágenes", "*.png", "*.jpg", "*.jpeg")
        );

        File file = fileChooser.showOpenDialog(btnSeleccionarLogo.getScene().getWindow());
        if (file != null) {
            lblRutaLogo.setText(file.getAbsolutePath());
        }
    }

    @FXML
    private void guardarConfiguracion() {
        try {
            // Guardar preferencias
            prefs.put("tema_preferido", cbxTema.getValue());
            prefs.put("nombre_universidad", txtNombreUniversidad.getText());
            prefs.put("direccion", txtDireccion.getText());
            prefs.put("telefono", txtTelefono.getText());
            prefs.put("email", txtEmail.getText());
            prefs.put("rector", txtRector.getText());
            prefs.put("ruta_logo", lblRutaLogo.getText());
            prefs.putBoolean("notificaciones", chkNotificaciones.isSelected());
            prefs.putBoolean("backup_automatico", chkBackupAutomatico.isSelected());
            prefs.putInt("intervalo_backup", spnIntervaloBackup.getValue());

            mostrarAlerta("Éxito", "Configuración guardada correctamente", Alert.AlertType.INFORMATION);

        } catch (Exception e) {
            mostrarAlerta("Error", "No se pudo guardar la configuración: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void restaurarValoresPorDefecto() {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Restaurar Valores por Defecto");
        alert.setHeaderText("¿Está seguro de restaurar los valores por defecto?");
        alert.setContentText("Esta acción no se puede deshacer.");

        if (alert.showAndWait().get() == ButtonType.OK) {
            try {
                prefs.clear();
                cargarConfiguracion();
                mostrarAlerta("Éxito", "Valores por defecto restaurados", Alert.AlertType.INFORMATION);
            } catch (Exception e) {
                mostrarAlerta("Error", "No se pudieron restaurar los valores: " + e.getMessage(), Alert.AlertType.ERROR);
            }
        }
    }

    private void aplicarTema(String tema) {
        try {
            // Aquí puedes implementar la lógica para cambiar temas
            // Por ahora, solo mostraremos un mensaje
            switch (tema) {
                case "Tema Claro":
                    System.out.println("✅ Tema Claro aplicado");
                    break;
                case "Tema Oscuro":
                    System.out.println("✅ Tema Oscuro aplicado");
                    break;
                case "Tema Institucional":
                    System.out.println("✅ Tema Institucional aplicado");
                    break;
            }
        } catch (Exception e) {
            System.err.println("❌ Error al aplicar tema: " + e.getMessage());
        }
    }

    private void mostrarAlerta(String titulo, String mensaje, Alert.AlertType tipo) {
        Alert alert = new Alert(tipo);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }
}